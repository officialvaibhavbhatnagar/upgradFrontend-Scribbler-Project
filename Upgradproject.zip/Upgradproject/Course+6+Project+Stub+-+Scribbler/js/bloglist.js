//    BOX1
$(document).ready(function(){
    $("#trashDeletepost").click(function(){
        $("#exampleModal").modal();
        $("#btnYes").click(function(){
            document.getElementById("boxFirst").style.display="none";
            $('#exampleModal').modal('hide');
        });
        $('#btnNo').click(function() {
        $('#exampleModal').modal('hide');
});
    });
    });

// BOX2
$(document).ready(function(){
    $("#trashDeletepost2").click(function(){
        $("#exampleModal").modal();
        $("#btnYes").click(function(){
            document.getElementById("boxSecond").style.display="none";
            $('#exampleModal').modal('hide');
        });
        $('#btnNo').click(function() {
        $('#exampleModal').modal('hide');
});
    });
    });


           // BOX2
$(document).ready(function(){
    $("#faThird").click(function(){
        $("#exampleModal").modal();
        $("#btnYes").click(function(){
            document.getElementById("boxThird").style.display="none";
            $('#exampleModal').modal('hide');
        });
        $('#btnNo').click(function() {
        $('#exampleModal').modal('hide');
});
    });
    });


    $(document).ready(function(){
    $("#trashDeletepost4").click(function(){
        $("#exampleModal").modal();
        $("#btnYes").click(function(){
            document.getElementById("boxFourth").style.display="none";
            $('#exampleModal').modal('hide');
        });
        $('#btnNo').click(function() {
        $('#exampleModal').modal('hide');
});
    });
    });


    $(document).ready(function(){
    $("#trashDeletepost5").click(function(){
        $("#exampleModal").modal();
        $("#btnYes").click(function(){
            document.getElementById("boxFifth").style.display="none";
            $('#exampleModal').modal('hide');
        });
        $('#btnNo').click(function() {
        $('#exampleModal').modal('hide');
});
    });
    });
